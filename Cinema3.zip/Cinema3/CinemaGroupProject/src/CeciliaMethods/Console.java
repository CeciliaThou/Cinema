/*
 * various methods to get information from the Console
 */
package CeciliaMethods;

/**
 *
 * @author CeTho1411
 */
import java.util.Scanner;

public class Console {
    
    public static int getInt()
    {
        Scanner input = new Scanner(System.in);    
        int num = 0;
        
        while (!input.hasNextInt())
        {
            System.out.print("not a real number... \nre-enter: ");
            input.nextLine();
        }
        
        num = input.nextInt();
        
        return num;
    }
    public static int getInt(String prompt)
    {
        int num = 0;
        System.out.print(prompt);
        num = getInt();
        return num;
        //return getInt();
    }
    public static int getInt(String prompt, int min) {
        Scanner input = new Scanner(System.in);

        int num = 0;

        num = getInt(prompt);
        while (num <= min) {
            System.out.println("integer must be > " + min);
            num = getInt(prompt);
        }
        return num;

    }
    
    public static int getInt(int min, String prompt) {
        Scanner input = new Scanner(System.in);

        int num = 0;

        num = getInt(prompt);
        while (num < min) {
            System.out.println("integer must be at least " + min);
            num = getInt(prompt);
        }
        return num;

    }
    
    //for GuessingGame
     public static int getInt(String prompt, int min, int max)
   {
       Scanner input = new Scanner(System.in);
       
       int num = 0;
      
        num = getInt(prompt);
        while (num < min || num > max)
        {
            System.out.println("integer must be  between " + min + " and " + max);
            num = getInt(prompt);
        }
        
       
       return num;  
   }
    
    public static double getDouble() {
        Scanner input = new Scanner(System.in);
        double num = 0;

        while (!input.hasNextDouble()) {
            System.out.print("not a real number... \nre-enter: ");
            input.nextLine();
        }

        num = input.nextDouble();

        return num;
    }

    public static double getDouble(String prompt) {
        double num = 0;
        System.out.print(prompt);
        num = getDouble();
        return num;
        //return getInt();
    }

    public static double getDouble(String prompt, double min) {
        Scanner input = new Scanner(System.in);

        double num = 0;

        num = getDouble(prompt);
        while (num <= min) {
            System.out.println("integer must be > " + min);
            num = getDouble(prompt);
        }
        return num;

    }
    
    public static double getDouble(double min, String prompt){
        Scanner input = new Scanner(System.in);

        double num = 0;

        num = getDouble(prompt);
        while (num < min) {
            System.out.println("double must be at least " + min);
            num = getDouble(prompt);
        }
        return num;

    }

    //for GuessingGame
    public static double getDouble(String prompt, double min, double max)
   {
       Scanner input = new Scanner(System.in);
       
       double num = 0;
      
       //loop till guess is correct
      
        num = getDouble(prompt);
        while (num < min || num > max)
        {
            System.out.println("integer must be  between " + min + " and " + max);
            num = getInt(prompt);
        }
       return num;  
   }
   
    //returns a boolean 
    
   
    
    //when picking up a string with nextLine()
    //make sure it itsn't empty
    public static String getString(String prompt){
        
        Scanner input = new Scanner(System.in);
        String word = "";
        
        System.out.print(prompt);
        word = input.nextLine().trim();
        
        //while (word.length() == 0 || word.equals(" ") || word.equals("\t") || word.equals("/"))
        //isEmpty() was used in class
        while (word.isEmpty())
        {
            System.out.println("missing input...");
            System.out.print(prompt);
            word = input.nextLine().trim();
        }
        return word;
    }
    
    public static boolean checkIntAsString (String text){
        
        boolean intOnly = true;
        int length = 0, unicode = 0;
        char newChar = ' ';

        text = text.replaceAll(" ", "").replaceAll("\t", "").toUpperCase();
        length = text.length();

        for (int index = 0; index < length && intOnly != false; index++) {
            newChar = text.charAt(index);
            unicode = (int) newChar;

            if (unicode < 48 || unicode > 57) {
                intOnly = false;
            }
        }

        return intOnly;
    }
    
   
    public static String getIntAsString (){
        
        Scanner input = new Scanner(System.in);
        String text = "";
        boolean intOnly = false;

        text = input.nextLine();
        intOnly = checkIntAsString(text);
        while (intOnly == false) {
            System.out.print("must enter only numbers ... \nre-enter: ");
            text = input.nextLine().trim().replaceAll(" ", "");
            intOnly = checkIntAsString(text);
        }

        return text;
    }
    
    public static float getFloat() {
        Scanner input = new Scanner(System.in);
        float num = 0;

        while (!input.hasNextFloat()) {
            System.out.print("not a real number... \nre-enter: ");
            input.nextLine();
        }

        num = input.nextFloat();

        return num;
    }

    public static float getFloat(String prompt) {
        float num = 0;
        System.out.print(prompt);
        num = getFloat();
        return num;
    }
    
    public static boolean checkNumber(String text)
    {
        boolean number = true;
        int length = 0, unicode = 0;
        char newChar = ' ';
        
        text = text.replaceAll(" ", "");
        length = text.length();
       
        for (int index = 0; index < length && number != false; index++)
        {
            newChar = text.charAt(index);
            unicode = (int) newChar;

            if (unicode < 48 || unicode > 57)
                number = false;
        }
        
        return number;
    }
    
    public static String getNumber(){
        
        Scanner input = new Scanner(System.in);
        String text = "";
        boolean number = false;
        
        text = input.nextLine();
        number = checkNumber(text);
        while (number == false)
        {
            System.out.print("must enter only numbers ... \nre-enter: ");
            text = input.nextLine().trim();
            number = checkNumber(text);
        }
        
        return text;
        
    }
}
