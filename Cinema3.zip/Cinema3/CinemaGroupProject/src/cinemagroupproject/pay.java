/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinemagroupproject;

/**
 *
 * @author cetho1411
 */
import CeciliaMethods.NumCalc;
import CeciliaMethods.Colour;
import java.util.Arrays;
import java.util.Scanner;
import java.io.*;

public class pay {
    

    public static boolean allNums(String cardNum)
    {
        boolean allNum = true;
        String numbers = "0123456789";
        
        for (int i = 0; i < cardNum.length() && allNum; i++)
        {
            if (numbers.indexOf(cardNum.substring(i, i + 1)) < 0)
                allNum = false;
        }
        
        return allNum;
    }

    
    public static String getCardNum(){
        
        Scanner input = new Scanner(System.in);
        
        String cardNum = "";
        boolean allNums = true;
        int length = 0;
        
        System.out.print("card number: ");
        cardNum = input.nextLine().replaceAll(" ", "");
        length = cardNum.length();
        allNums = allNums(cardNum);
        
        while (!allNums || length != 16)
        {
            if (length != 16)
                System.out.println("must enter 16 digits");
            if (!allNums)
                System.out.println("must enter only numbers");
            
            System.out.print("card number: ");
            cardNum = input.nextLine().replaceAll(" ", "");
            length = cardNum.length();
            allNums = allNums(cardNum);
        }
        return cardNum;
    }

     public static int getUserInfo(String[] userInfo){
     
         Scanner input = new Scanner(System.in);
         
         String fName = "", sName = "", email = "", cardNum = "";
         int province = 0;
         boolean allNums = true, checkNums = true;
         
         System.out.println("");
         fName = CeciliaMethods.Console.getString("first name: ");
         sName = CeciliaMethods.Console.getString("surname: ");
         email = CeciliaMethods.Console.getString("email: ");
         cardNum = getCardNum();
         
         System.out.println(cardNum);
          
         userInfo[0] = fName;
         userInfo[1] = sName;
         userInfo[2] = email;
         userInfo[3] = cardNum;
         
         
         System.out.println("1.  Quebec\n2.  British Columbia\n3.  Manitoba\n4.  NewBrunswick"
                 + "\n5.  Newfoundland and Labrador\n6.  Nova Scotia\n7.  Ontario\n8.  Prince Edward Island"
                 + "\n9.  Alberta\n10. Saskatchewan\n");
         province = CeciliaMethods.Console.getInt("province: ", 1, 10);
         province -= 1;

         return province;
     }
     
    public static int displaySeats(String[] seats, int selectedSeat, int unicode, int[] selectedSeats){
        
        unicode = unicode - 65;
        selectedSeat = selectedSeat + (unicode * 20);
        
        
        System.out.print((char) 65 + "   ");
        for (int i = 1, row = 66; i < seats.length; i++)
        {
            if (selectedSeat == i)
                seats[i] = Colour.RED_BACKGROUND + seats[i] + Colour.RESET;
            
            System.out.print(seats[i] + " ");
            if ((i) % 20 == 0 && row != 75) {
                System.out.println("");
                System.out.print((char) row + "   ");
                row++;
            }
        }
        
        System.out.println("");
        return selectedSeat;
    }
    
    public static void pickSeats(String[] seats, int numTickets, int[] selectedSeats, String[] rowSeatArray){
   
        String rowLetter = "";
        char letter = ' ';
        int unicode = 0, seatNum = 0;
        
        displaySeats(seats, seatNum, unicode, selectedSeats);
        
        for (int i = 0; i < numTickets; i++)
        {
            rowLetter = CeciliaMethods.Console.getString("\nrow (A-J): ");
            letter = rowLetter.toUpperCase().charAt(0);
            unicode = (int) letter;

            while (unicode < 65 || unicode > 74)
            {
                System.out.print("must enter a letter (A-J)");
                rowLetter = CeciliaMethods.Console.getString("\nre-enter: ");
                letter = rowLetter.toUpperCase().charAt(0);
                unicode = (int) letter;
            }

            seatNum = CeciliaMethods.Console.getInt("seat: ", 1, 20);

            System.out.println("\nRow: " + letter + "\nSeat: " + seatNum);

            if (seatNum >= 10)
                rowSeatArray[i] = "" + letter + seatNum;
            else 
                rowSeatArray[i] = "" + letter + "0" + seatNum;
            
            
            selectedSeats[i] = displaySeats(seats, seatNum, unicode, selectedSeats);
        }
        
    }
    
    public static void populateProvinceArray(ProvinceTaxObject[] provinceArray, Scanner reader)
    {
        String province = "";
        float QST = 0;
        int PST = 0, GST = 0, HST = 0;
        
        for (int i = 0; reader.hasNext() && i < provinceArray.length; i++) {
            province = reader.next();
            QST = reader.nextFloat();
            PST = reader.nextInt();
            GST = reader.nextInt();
            HST = reader.nextInt();

            provinceArray[i] = new ProvinceTaxObject(province, QST, PST, GST, HST);
        }
    }
    
    public static void populateSeatArray(String[] seats){
        
        for (int i = 1, seatNum = 1; i < seats.length; i++, seatNum++) {
            seats[i] = "" + seatNum;

            if (i % 20 == 0) 
                seatNum = 0;
        }
    }
    
    public static void createInvoice(String[] userInfo, int provinceIndex, 
                                     ProvinceTaxObject[] provinceArray, double subtotal, double total,
                                     String genre, String movie, int[] numTickets, String[] rowSeatArray) throws IOException{
        
        PrintWriter outputFile = new PrintWriter("invoice");
        
        String txt = "";
        int index = 0;
        double taxes = total - subtotal;
        taxes = CeciliaMethods.NumCalc.round(taxes, 2);
        
        outputFile.println("Movie Theaters");
        outputFile.println("Transaction Receipt");
        
        outputFile.println("\nInvoice #");
        outputFile.println("Issued to " + userInfo[0] + " " + userInfo[1]);
        outputFile.println("email: " + userInfo[2]);
        outputFile.println("card number: **** **** **** " + userInfo[3].substring(12));
        outputFile.println("Province: " + provinceArray[provinceIndex].province);
        
        outputFile.println("\n*****************************************\n");
        
        outputFile.println("Genre: " + genre);
        outputFile.println("Movie: " + movie);

        
        outputFile.println("Tickets:\t\t\tPrice:\n");
        
        
        for (int i = 0; i < numTickets[0]; i++)
        {
            outputFile.println("General Admit (" + rowSeatArray[index] + ")\t\t$10.99");
            index++;        
        }
        
        for (int i = 0; i < numTickets[1]; i++)
        {
            outputFile.println("Senior        (" + rowSeatArray[index] + ")\t\t$ 8.50");
            index++;
        }

        for (int i = 0; i < numTickets[2]; i++)
        {
            outputFile.println("Child         (" + rowSeatArray[index] + ")\t\t$ 7.50");
            index++;
        }
        
        outputFile.println("\n*****************************************\n");

            if (subtotal >= 10)
                outputFile.println("Subtotal:\t\t\t$" + subtotal);
            else
                outputFile.println("Subtotal:\t\t\t$ " + subtotal); 
            
            if (taxes >= 10)
                outputFile.println("Taxes:  \t\t\t$" + taxes);
            else if (taxes < 10)
                outputFile.println("Taxes:  \t\t\t$ " + taxes);
            
            if (total >= 10)
                outputFile.println("Total:  \t\t\t$" + total);
            else
                outputFile.println("Total:  \t\t\t$ " + total);
        
        outputFile.close();
        //invoice.close();
    }
    
    public static double getTotal(int provinceIndex, ProvinceTaxObject[] provinceArray, double subtotal){
        
        String province = "";
        float QST = 0;
        int PST = 0, GST = 0, HST = 0;
        
        double total = 0, taxes = 0, taxPercent = 0;
        
        province = provinceArray[provinceIndex].province;
        QST = provinceArray[provinceIndex].QST;
        PST = provinceArray[provinceIndex].PST;
        GST = provinceArray[provinceIndex].GST;
        HST = provinceArray[provinceIndex].HST;
    
        taxPercent = QST + PST + GST + HST;
        
        taxes = subtotal * (taxPercent/100);      
        total = subtotal + taxes;
        total = NumCalc.round(total, 2);
        
        return total;
    }
    
    public static void main(String[] args) throws IOException{
        
        File inFile = new File("provinceTax");
        Scanner reader = new Scanner(inFile);
        reader.useDelimiter(";|\n");
        
        String[] seats = new String[201];
        
        String companyName = "";
        
        //{fName,surname,email,cardNum}
        String[] userInfo = new String[4];
        int provinceIndex = 0;
        
        //user's chosen seats
        int[] selectedSeats = new int[200]; 
        
        int[] numTickets = {1, 0, 0};//from Musab's program
        int totalTickets = numTickets[0] + numTickets[1] + numTickets[2];
        String[] rowSeatArray = new String[totalTickets];
        
        
        populateSeatArray(seats);
        
        ProvinceTaxObject[] provinceArray = new ProvinceTaxObject[10];
        
        populateProvinceArray(provinceArray, reader);
        
        pickSeats(seats, totalTickets, selectedSeats, rowSeatArray);
        
        provinceIndex = getUserInfo(userInfo);
        
       
        //****************
        //these variables are for testing 
        double subtotal = 10.99, total = 0, tax = 0;
        
        total = getTotal(provinceIndex, provinceArray, subtotal);
        String genre = "a genre", movie = "a movie";    
        
        createInvoice(userInfo, provinceIndex, provinceArray, subtotal, total, genre, movie, numTickets, rowSeatArray);
        
    }
    
}
