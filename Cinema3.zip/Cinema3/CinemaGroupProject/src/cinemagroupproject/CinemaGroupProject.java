/*
 * Writing to the provinceTax File
 */
package cinemagroupproject;

/**
 *
 * @author cetho1411
 */
import java.io.*;
import java.util.Scanner;

public class CinemaGroupProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        
        PrintWriter outputFile = new PrintWriter("provinceTax");
        
        String province = "Quebec";
        int PST = 0, GST = 0, HST = 0;
        float QST = 0;
        
        System.out.println("to stop, enter *\n");
        
        province = CeciliaMethods.Console.getString("province: ");
        
        while (!province.contains("*"))
        {
            QST = CeciliaMethods.Console.getFloat("QST: ");
            PST = CeciliaMethods.Console.getInt("PST: ");
            GST = CeciliaMethods.Console.getInt("GST: ");
            HST = CeciliaMethods.Console.getInt("HST: ");
            
            outputFile.print(province + ";" + QST + ";" + PST + ";" + GST + ";" + HST + "\n");
            
            province = CeciliaMethods.Console.getString("province: ");
        }
        
        outputFile.close();
        
    }
    
}
