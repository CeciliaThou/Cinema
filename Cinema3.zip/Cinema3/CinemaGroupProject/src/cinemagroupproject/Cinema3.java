/*
 * Johnson = display movies and genres
 * Musab = shopping cart
 * Cecilia = pay and invoice
 */
package cinemagroupproject;

/**
 *
 * @author cetho1411
 */

import java.util.Scanner;
import java.util.Arrays;
import java.io.*;
import MyMethods.Console; //Johnson's methods
import CeciliaMethods.*;
import MusabsMethods.*;

public class Cinema3 {
    
    //Johnson's part
    public static int fillArrays(int arraySize, String[] genres, String[] movie1,String[] times1, String[] movie2, String[] times2, String[] movie3, String[] times3)throws IOException
    {
        File inFile = new File ("movies.txt");
        Scanner reader = new Scanner(inFile);
        reader.useDelimiter(";|\n");
        
        for(int i=0;reader.hasNext();i++)
        {
           genres[i] = reader.next();
           movie1[i] = reader.next();
           times1[i] = reader.next();
           movie2[i] = reader.next();
           times2[i] = reader.next();
           movie3[i] = reader.next();
           times3[i] = reader.next();
           arraySize++;
        }
        
        for(int i=0; i<=8;i++)
        {
            System.out.print(genres[i]+", ");
            System.out.print(movie1[i]+", "+times1[i]+", ");
            System.out.print(movie2[i]+", "+times2[i]+", ");
            System.out.println(movie3[i]+", "+times3[i]+", ");
        }
        
        return arraySize;
    }
    
    public static String getGenre(String userGenre, int arraySize, String[] genres)
    {
        Scanner input = new Scanner(System.in);
        
        boolean validGenre = false;
        
        System.out.println("");
        System.out.println("What Genre of Movie would you Like?");
        System.out.println("Choices: "+Arrays.toString(genres));
        userGenre = input.nextLine();
        
        for(int i=0;i<arraySize && validGenre == false;i++)
        {
            if(userGenre.equalsIgnoreCase(genres[i]))
            {
                validGenre = true;
                userGenre = genres[i];
            }
        }
        
        while(validGenre == false)
        {
            System.out.println("Please Enter a Valid Genre: ");
            userGenre = input.nextLine();
            
            for(int i=0;i<9;i++)
        {
            
            if(userGenre.equalsIgnoreCase(genres[i]))
            {
                validGenre = true;
                userGenre = genres[i];
                
            }
        }
        }
        return userGenre;
    }
    
    public static String getMovie(String choosenMovie, String userGenre, int arraySize, String[] genres, String[] movie1,String[] times1, String[] movie2, String[] times2, String[] movie3, String[] times3)
    {
        //REMEMBER, USE THE INDEXOF AND THEN USE THAT INDEX TO GET THE CORRISPONDING TIMES AND MOVIES
        
        Scanner input = new Scanner(System.in);
        
        int index = 0;
        int movieNum = 0;
        
        for(int i=0;i<arraySize;i++)
        {
            if(userGenre.equals(genres[i]))
            {
                index = i;
            }
        }   
        
        System.out.println("index: " + index);
        
        System.out.println("1: "+movie1[index]);
        System.out.println("2: "+movie2[index]);
        System.out.println("3: "+movie3[index]);
        
        movieNum = Console.getInt("Which Movie would you Like?",4,1);
        
        if(movieNum==1)
            choosenMovie=movie1[index];
        else if(movieNum==2)
            choosenMovie=movie2[index];
        else
            choosenMovie=movie3[index];
        
        System.out.println("the choosen one: "+choosenMovie);
        return choosenMovie;
    }
    
    public static String getTime(String movieTime, String choosenMovie, String userGenre, int arraySize, String[] genres, String[] movie1,String[] times1, String[] movie2, String[] times2, String[] times3)
    {
        int index = 0;
        
        for(int i=0;i<arraySize;i++)
        {
            if(userGenre.equals(genres[i]))
            {
                index = i;
            }
        } 
        
        if(choosenMovie.equals(movie1[index]))
            movieTime = times1[index];
        else if(choosenMovie.equals(movie2[index]))
            movieTime = times2[index];
        else
            movieTime = times3[index];
        
        return movieTime;
    }
    //get the genres by comparing the input by using .equalsignorecase
    //the use that index to find the movies and ask which one they want
    //by that you should be able to get the time of the movie
    //finally just return everything that we need to the main and your ready to
    //do little changes or make the UI look better
    
    //*******************************************************************************
    
    //Musab's part
    public static Scanner input = new Scanner(System.in);
    public static final double GENERAL_ADMIT = 10.99;
    public static final double SENIOR = 8.50;
    public static final double CHILD = 7.50;
           
    public static void displayOptions()
    {
        System.out.println("1 - Add tickets");
        System.out.println("2 - Remove tickets");
        System.out.println("3 - Proceed to checkout");
    }
    public static void displayTickets2()
    {
        System.out.println(" 4. Proceed to order summary");
        System.out.println("*****************************");
    }
    public static void displayTickets1()
    {
        System.out.println("\nTicket Prices:");
        System.out.println("*****************************");
        System.out.println(" 1. General Admit:   $"+GENERAL_ADMIT);
        System.out.println(" 2. Senior  (65+):    $"+SENIOR);
        System.out.println(" 3. Child  (1-13):    $"+CHILD);
        System.out.println("*****************************");
    } 
    
    public static int getHighest(int[] numTickets)
    {
        int[] copy = Arrays.copyOf(numTickets,numTickets.length);
        Arrays.sort(copy);
        
        return copy[2];
    }
    
    public static double getSubtotal(int ticketWanted,double subtotal,int[] numTickets,int numTicketWanted,String[] ticket)
    {
        if (ticketWanted == 1)
            {
                numTicketWanted = 0;
                numTicketWanted = MusabsMethods.Console.getInt("How many "+ticket[0]+" Tickets do you want: ",0,10);
                numTickets[0]+=numTicketWanted;
                subtotal += (GENERAL_ADMIT * numTicketWanted);
            }
        else if (ticketWanted == 2)
            {
                numTicketWanted = 0;
                numTicketWanted = MusabsMethods.Console.getInt("How many "+ticket[1]+" tickets do you want: ",0,10);
                numTickets[1]+=numTicketWanted;
                subtotal += (SENIOR * numTicketWanted);
            }
        else
            {
                numTicketWanted = 0;
                numTicketWanted = MusabsMethods.Console.getInt("How many "+ticket[2]+" tickets do you want: ",0,10);
                numTickets[2]+=numTicketWanted;
                subtotal += (CHILD * numTicketWanted);
            }
        return subtotal;
    }
    
    public static double remove(int[] numTickets,double subtotal,String[] ticket)
    {
        int choice = 0;
        int numRemove = 0;
        int highest = getHighest(numTickets);
        for (int i = 0; i<ticket.length;i++)
        {
            System.out.println((i+1)+" - "+ticket[i]+": "+numTickets[i]);
        }
        System.out.println("");
        choice = MusabsMethods.Console.getInt("What ticket would you like to remove: ",1,3);
        numRemove = MusabsMethods.Console.getInt("How many would you like to remove: ",0,highest);
        while ((choice == 1 && numRemove>numTickets[0])||(choice == 2 && numRemove>numTickets[1])||
                (choice == 3 && numRemove>numTickets[2]))
        {
            System.out.println(Colour.RED+"Error.... can't have -ve tickets"+Colour.RESET);
            System.out.println(Colour.RED+"If there are 0 tickets enter 0"+Colour.RESET);
            numRemove = Console.getInt("How many would you like to remove: ",0,highest);
        }
        switch (choice) {
            case 1:
                subtotal -= numRemove * GENERAL_ADMIT;
                numTickets[0]-=numRemove;
                break;
            case 2:
                subtotal -= numRemove * SENIOR;
                numTickets[1]-=numRemove;
                break;
            default:
                subtotal -= numRemove * CHILD;
                numTickets[2]-=numRemove;
                break;
        }
        return subtotal;
    }
    
    public static double add(int[] numTickets,double subtotal,String[] ticket)
    {
        int ticketWanted = 0;
        int numTicketWanted = 0;
        
        displayTickets1();
        ticketWanted = MusabsMethods.Console.getInt("What ticket do you want: ",1,3);
        subtotal = getSubtotal(ticketWanted,subtotal,numTickets,numTicketWanted,ticket);
        
        return subtotal;
    }
    
    public static void orderSummary(String[] ticket, int[] numTickets,double subtotal,String genre,String movie)
    {
        
        System.out.println("\n*************************");
        System.out.println("Order Summary");
        System.out.println(genre+": "+movie);
        System.out.println("Tickets: ");
        for (int i = 0; i<ticket.length;i++)
        {
            if(numTickets[i]==0)
            {}
            else
            System.out.println(ticket[i]+": "+numTickets[i]);
        }
        System.out.println("Subtotal: $"+subtotal);
        System.out.println("");
    }
    
    public static double getTickets(int[] numTickets,String[] ticket)
    {
        int ticketWanted = 0;
        int numTicketWanted = 0;
        double subtotal= 0;
        
        displayTickets1();
        displayTickets2();
        ticketWanted = MusabsMethods.Console.getInt("What ticket do you want(1-3): ",1,4);
        
        while (ticketWanted == 4)
        {
            System.out.println(Colour.RED+"You can't proceed without purchasing a ticket"+Colour.RESET);
            ticketWanted = MusabsMethods.Console.getInt("What ticket do you want(1-3): ",1,4);
        }
        
        while (ticketWanted != 4)
        {
            subtotal = getSubtotal(ticketWanted,subtotal,numTickets,numTicketWanted,ticket);
            
            displayTickets1();
            displayTickets2();
            System.out.println("subtotal: "+subtotal+"\n");
            ticketWanted = 0;
            ticketWanted = MusabsMethods.Console.getInt("What other tickets do you want: ",1,4);
            numTicketWanted = 0;
        }
        return subtotal;
    }
    public static double shoppingCart(String[] ticket, int[] numTickets,double subtotal,String genre,String movie)
    {
        int choice;
        boolean proceed = false;
        
        
        while(!proceed)
        {
            orderSummary(ticket,numTickets,subtotal,genre,movie);
            displayOptions();
            choice = MusabsMethods.Console.getInt("Choice: ",1,3);
        switch (choice){
            case 1:
                subtotal = add(numTickets,subtotal,ticket);
                break;
            case 2:
                subtotal = remove(numTickets,subtotal,ticket);
                break;
            default:
                proceed = true;
                break;
        }
        }
        
        return subtotal;
    }
    
    //****************************************************************************
    
    //Cecilia's part
    public static boolean allNums(String cardNum)
    {
        boolean allNum = true;
        String numbers = "0123456789";
        
        for (int i = 0; i < cardNum.length() && allNum; i++)
        {
            if (numbers.indexOf(cardNum.substring(i, i + 1)) < 0)
                allNum = false;
        }
        
        return allNum;
    }

    
    public static String getCardNum(String prompt){
        
        Scanner input = new Scanner(System.in);
        
        String cardNum = "";
        boolean allNums = true;
        int length = 0;
        
        System.out.print(prompt);
        cardNum = input.nextLine().replaceAll(" ", "");
        length = cardNum.length();
        allNums = allNums(cardNum);
        
        while (!allNums || length != 16)
        {
            if (length != 16)
                System.out.println("must enter 16 digits");
            if (!allNums)
                System.out.println("must enter only numbers");
            
            System.out.print("card number: ");
            cardNum = input.nextLine().replaceAll(" ", "");
            length = cardNum.length();
            allNums = allNums(cardNum);
        }
        return cardNum;
    }
    
    public static int getUserInfo(String[] userInfo){
     
         Scanner input = new Scanner(System.in);
         
         String fName = "", sName = "", email = "", cardNum = "";
         int province = 0;
         boolean allNums = true, checkNums = true;
         
         System.out.println("");
         fName = CeciliaMethods.Console.getString("first name: ");
         sName = CeciliaMethods.Console.getString("surname: ");
         email = CeciliaMethods.Console.getString("email: ");
         cardNum = getCardNum("card number: ");
          
         userInfo[0] = fName;
         userInfo[1] = sName;
         userInfo[2] = email;
         userInfo[3] = cardNum;
         
         System.out.println("\n1.  Quebec\n2.  British Columbia\n3.  Manitoba\n4.  NewBrunswick"
                 + "\n5.  Newfoundland and Labrador\n6.  Nova Scotia\n7.  Ontario\n8.  Prince Edward Island"
                 + "\n9.  Alberta\n10. Saskatchewan\n");
         province = CeciliaMethods.Console.getInt("province: ", 1, 10);
         province -= 1;

         return province;
     }
     
    public static int displaySeats(String[] seats, int actualSeatNum, int[] selectedSeats){
        
        
        System.out.print((char) 65 + "   ");
        for (int i = 1, row = 66; i < seats.length; i++)
        {
            if (actualSeatNum == i)
                seats[i] = Colour.RED_BACKGROUND + seats[i] + Colour.RESET;
            
            System.out.print(seats[i] + " ");
            if ((i) % 20 == 0 && row != 75) {
                System.out.println("");
                System.out.print((char) row + "   ");
                row++;
            }
        }
        
        System.out.println("");
        return actualSeatNum;
    }
    public static boolean checkSeats(int actualSeatNum, int[] selectedSeats, int i){
        
        boolean differentSeats = true;
        
        for (int index = 0; index < i && differentSeats; index++)
        {
            if (actualSeatNum == selectedSeats[index])
                differentSeats = false;
        }
        
        return differentSeats;
    }
    public static int getSeats(String[] seats, int numTickets, int[] selectedSeats, String[] rowSeatArray, int i){
        
        String rowLetter = "";
        char letter = ' ';
        int unicode = 0, seatNum = 0, actualSeatNum = 0; // actualSeatNum = F13 = 113
        boolean differentSeat = true;
        
        rowLetter = CeciliaMethods.Console.getString("\nrow (A-J): ");
        letter = rowLetter.toUpperCase().charAt(0);
        unicode = (int) letter;

        while (unicode < 65 || unicode > 74)
        {
            System.out.print("must enter a letter (A-J)");
            rowLetter = CeciliaMethods.Console.getString("\nre-enter: ");
            letter = rowLetter.toUpperCase().charAt(0);
            unicode = (int) letter;
        }

        seatNum = CeciliaMethods.Console.getInt("seat: ", 1, 20);

        actualSeatNum = seatNum + ((unicode - 65) * 20);

        differentSeat = checkSeats(actualSeatNum, selectedSeats, i);
        
        //makes sure user can't pick the same seat
        while (!differentSeat)
        {
            System.out.println(CeciliaMethods.Colour.RED + "This seat has already been chosen..."
                               + "\npick a different seat" + CeciliaMethods.Colour.RESET);
            
            rowLetter = CeciliaMethods.Console.getString("\nrow (A-J): ");
            letter = rowLetter.toUpperCase().charAt(0);
            unicode = (int) letter;

            while (unicode < 65 || unicode > 74)
            {
                System.out.print("must enter a letter (A-J)");
                rowLetter = CeciliaMethods.Console.getString("\nre-enter: ");
                letter = rowLetter.toUpperCase().charAt(0);
                unicode = (int) letter;
            }

            seatNum = CeciliaMethods.Console.getInt("seat: ", 1, 20);

            actualSeatNum = seatNum + ((unicode - 65) * 20);

            differentSeat = checkSeats(actualSeatNum, selectedSeats, i);
        }

        System.out.println("\nRow: " + letter + "\nSeat: " + seatNum);

        if (seatNum >= 10)
            rowSeatArray[i] = "" + letter + seatNum;
        else 
            rowSeatArray[i] = "" + letter + "0" + seatNum;

        return actualSeatNum;
    }
    
    public static void pickSeats(String[] seats, int numTickets, int[] selectedSeats, String[] rowSeatArray){
   
       
        int  actualSeatNum = 0, choice = 0; // actualSeatNum = F13 = 113
        
        displaySeats(seats, actualSeatNum, selectedSeats);
        
        for (int i = 0; i < numTickets; i++)
        {
            actualSeatNum = getSeats(seats, numTickets, selectedSeats, rowSeatArray, i);
            selectedSeats[i] = displaySeats(seats, actualSeatNum, selectedSeats);
        }

        
    }
    
    public static void populateProvinceArray(ProvinceTaxObject[] provinceArray, Scanner reader)
    {
        String province = "";
        float QST = 0;
        int PST = 0, GST = 0, HST = 0;
        
        for (int i = 0; reader.hasNext() && i < provinceArray.length; i++) {
            province = reader.next();
            QST = reader.nextFloat();
            PST = reader.nextInt();
            GST = reader.nextInt();
            HST = reader.nextInt();

            provinceArray[i] = new ProvinceTaxObject(province, QST, PST, GST, HST);
        }
    }
    
    public static void populateSeatArray(String[] seats){
        
        for (int i = 1, seatNum = 1; i < seats.length; i++, seatNum++) {
            seats[i] = "" + seatNum;

            if (i % 20 == 0) 
                seatNum = 0;
        }
    }
    
    public static void createInvoice(String[] userInfo, int provinceIndex, 
                                     ProvinceTaxObject[] provinceArray, double subtotal, double total,
                                     String genre, String movie, int[] numTickets, String[] rowSeatArray, 
                                     String movieTime, int invoiceNum) throws IOException{
        
        PrintWriter outputFile = new PrintWriter("invoice");
        PrintWriter outputNum = new PrintWriter("invoiceNumber");
        
        String txt = "";
        int index = 0;
        double taxes = 0;
        subtotal = CeciliaMethods.NumCalc.round(subtotal, 2);
        taxes = total - subtotal;
        taxes = CeciliaMethods.NumCalc.round(taxes, 2);
        
        outputFile.println("Movie Theaters");
        outputFile.println("Transaction Receipt");
        
        outputFile.println("\nInvoice #" + invoiceNum);
        outputFile.println("Issued to " + userInfo[0] + " " + userInfo[1]);
        outputFile.println("email: " + userInfo[2]);
        outputFile.println("card number: **** **** **** " + userInfo[3].substring(12));
        outputFile.println("Province: " + provinceArray[provinceIndex].province);
        
        outputFile.println("\n*****************************************\n");
        
        outputFile.println("Genre: " + genre);
        outputFile.println("Movie: " + movie);
        outputFile.println("Time:  " + movieTime);
        outputFile.println("\nTickets:\t\t\tPrice:\n");
        
        
        for (int i = 0; i < numTickets[0]; i++)
        {
            outputFile.println("General Admit (" + rowSeatArray[index] + ")\t\t$ 10.99");
            index++;        
        }
        
        for (int i = 0; i < numTickets[1]; i++)
        {
            outputFile.println("Senior        (" + rowSeatArray[index] + ")\t\t$  8.50");
            index++;
        }

        for (int i = 0; i < numTickets[2]; i++)
        {
            outputFile.println("Child         (" + rowSeatArray[index] + ")\t\t$  7.50");
            index++;
        }
        
        outputFile.println("\n*****************************************\n");
            if (subtotal >= 100)
                outputFile.println("Subtotal:\t\t\t$" + subtotal);
            else if (subtotal >= 10)
                outputFile.println("Subtotal:\t\t\t$ " + subtotal);
            else
                outputFile.println("Subtotal:\t\t\t$  " + subtotal); 

            if (taxes >= 10)
                outputFile.println("Tax:    \t\t\t$ " + taxes);
            else if (taxes < 10)
                outputFile.println("Tax:    \t\t\t$  " + taxes);
            
            if (total >= 100)
                outputFile.println("Total:  \t\t\t$" + total);
            if (total >= 10)
                outputFile.println("Total:  \t\t\t$ " + total);
            else
                outputFile.println("Total:  \t\t\t$  " + total);
        
        invoiceNum++;
        outputNum.print(invoiceNum);
        
        outputNum.close();
        outputFile.close();
        
        System.out.println("\nYour total is $" + total + ".");
        System.out.println("A reciept will be emailed to you.");
        System.out.println("Thanks for booking with us!");
        System.out.println("Have a nice day!");
    }
    
    public static double getTotal(int provinceIndex, ProvinceTaxObject[] provinceArray, double subtotal){
        
        String province = "";
        float QST = 0;
        int PST = 0, GST = 0, HST = 0;
        
        double total = 0, taxes = 0, taxPercent = 0;
        
        province = provinceArray[provinceIndex].province;
        QST = provinceArray[provinceIndex].QST;
        PST = provinceArray[provinceIndex].PST;
        GST = provinceArray[provinceIndex].GST;
        HST = provinceArray[provinceIndex].HST;
    
        taxPercent = QST + PST + GST + HST;
        
        taxes = subtotal * (taxPercent/100);      
        total = subtotal + taxes;
        total = NumCalc.round(total, 2);
        
        return total;
    }
    
    public static int getInvoiceNum() throws IOException{
        
        File inFile = new File("invoiceNumber");
        Scanner reader = new Scanner(inFile);
        
        int invoiceNum = reader.nextInt();
        return invoiceNum;
    }
    
    
    public static void updateInvoiceNum(int invoiceNum) throws IOException{
    
        PrintWriter outputFile = new PrintWriter("invoiceNumber");
        
        invoiceNum++;
        outputFile.print(invoiceNum);
        outputFile.close();
    }
    
    
    public static void main(String[] args) throws IOException{
        
        //Johnson
        String[] genres = new String[9];
        String[] movie1 = new String[9];
        String[] times1 = new String[9];
        String[] movie2 = new String[9];
        String[] times2 = new String[9];
        String[] movie3 = new String[9];
        String[] times3 = new String[9];

        int arraySize = 0;
        String userGenre = "";
        String choosenMovie = "";
        String movieTime = "";

        arraySize = fillArrays(arraySize, genres, movie1, times1, movie2, times2, movie3, times3);

        userGenre = getGenre(userGenre, arraySize, genres);

        choosenMovie = getMovie(choosenMovie, userGenre, arraySize, genres, movie1, times1, movie2, times2, movie3, times3);

        movieTime = getTime(movieTime, choosenMovie, userGenre, arraySize, genres, movie1, times1, movie2, times2, times3);
        //g: horror, comedy, action
            System.out.println("");
            System.out.println("Genre: "+userGenre);
            System.out.println("Movie: "+choosenMovie);
            System.out.println("movieTime: "+movieTime);
            
        //Musab
        String[] ticket = {"General Admit","Senior","Child"};
        int[] numTickets = new int[3];
        double subtotal = 0;


        subtotal = getTickets(numTickets,ticket);
        subtotal = shoppingCart(ticket,numTickets,subtotal,userGenre,choosenMovie);

        
        //Cecilia
        File inFile = new File("provinceTax");
        Scanner reader = new Scanner(inFile);
        reader.useDelimiter(";|\n");

        String[] seats = new String[201];
        
        String companyName = "";
        
        //{fName,surname,email,cardNum}
        String[] userInfo = new String[4];
        int provinceIndex = 0;
        
        double total = 0, tax = 0;
        int invoiceNum = 0;
        
        //user's chosen seats
        int[] selectedSeats = new int[200]; 
        
        
        int totalTickets = numTickets[0] + numTickets[1] + numTickets[2];
        String[] rowSeatArray = new String[totalTickets];
        
        
        populateSeatArray(seats);
        
        ProvinceTaxObject[] provinceArray = new ProvinceTaxObject[10];
        
        populateProvinceArray(provinceArray, reader);
        
        pickSeats(seats, totalTickets, selectedSeats, rowSeatArray);
        
        provinceIndex = getUserInfo(userInfo);
        
        total = getTotal(provinceIndex, provinceArray, subtotal);
        
        invoiceNum = getInvoiceNum();

        createInvoice(userInfo, provinceIndex, provinceArray, subtotal, total, userGenre, choosenMovie, numTickets, rowSeatArray, movieTime, invoiceNum); 
        
        updateInvoiceNum(invoiceNum);
    }
    
}
