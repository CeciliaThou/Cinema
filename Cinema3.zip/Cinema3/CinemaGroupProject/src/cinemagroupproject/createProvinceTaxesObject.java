/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinemagroupproject;

/**
 *
 * @author cetho1411
 */
class createProvinceTaxesObject {

    public String province;
    public float QST;
    public int PST;
    public int GST;
    public int HST;
    
    public createProvinceTaxesObject(String p, float qst, int pst, int gst, int hst)
    {
        province = p;
        QST = qst;
        PST = pst;
        GST = gst;
        HST = hst;
    }
    
}
