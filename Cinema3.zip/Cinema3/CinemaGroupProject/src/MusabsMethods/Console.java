/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MusabsMethods;

/**
 *
 * @author cetho1411
 */
import java.util.Scanner;
public class Console {
    
        public static int getInt()
    {
        Scanner input = new Scanner(System.in);
        int num = 0 ;
        
        while (!input.hasNextInt())
        {
            System.out.print("Not a Real Number.... re-enter: ");
            input.nextLine();
        }
        num=input.nextInt();
        
        return num;
    }
    
    public static int getInt(String prompt)
    {
        System.out.print(prompt);
        return getInt();
    }
    
    public static int getInt(String prompt, int min, int max)
    {  int num=0;
        
        num = getInt(prompt);
        while (num>max || num<min)
        {
            System.out.println("integer must be between " + min +
                                " and "+ max);
            num=getInt(prompt);
        }
        return num;    
            
            
    }
    
     public static int getInt(String prompt, int max)
    {
        int num=0;
        
        num = getInt(prompt);
        while (num>max)
        {
            System.out.println("integer must be <= "+max);
            num=getInt(prompt);
        }
        return num;
    
    }
     
    public static double getDouble()
    {
        Scanner input = new Scanner(System.in);
        double num = 0 ;
        
        while (!input.hasNextDouble())
        {
            System.out.print("Not a Real Number.... re-enter: ");
            input.nextLine();
        }
        num=input.nextDouble();
        
        return num;
    }
    
    public static double getDouble(String prompt)
    {
        System.out.print(prompt);
        return getDouble();
    }
    
    public static double getDouble(String prompt, int min, int max)
    {  double num=0;
        
        num = getInt(prompt);
        while (num>max || num<min)
        {
            System.out.println("integer must be between " + min +
                                " and "+ max);
            num=getDouble(prompt);
        }
        return num;    
            
            
    }
    
     public static double getDouble(String prompt, int max)
    {
        double num=0;
        
        num = getDouble(prompt);
        while (num>max)
        {
            System.out.println("integer must be <= "+max);
            num=getDouble(prompt);
        }
        return num;
    
    }

    
}
