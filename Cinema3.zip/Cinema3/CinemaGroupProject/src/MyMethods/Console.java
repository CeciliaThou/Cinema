/*
 * various methods to get information from the console
 */
package MyMethods;

import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author jophe4285
 */
public class Console 
{
public static int getInt()
{
{
    Scanner input = new Scanner(System.in);
        
    int num=0;
    
    while(!input.hasNextInt())
        {
            System.out.println("invaild re-enter: ");
            input.nextLine();
        }
    num = input.nextInt();
    return num;
}
}


public static int getInt(String prompt)
{
{
    System.out.print(prompt);
    return getInt();
}
}

public static int getInt(String Prompt, int max)
    {
    int num=0;
        System.out.print(Prompt);
        num = getInt();
            while(num>=max)
            {
                System.out.println("Number too large");
            num = getInt();
            }
        return num;
    }
    
    public static int getInt(String Prompt, int max, int min)
    {
    int num = 0;
            num=getInt(Prompt,max);
                    while(num<min)
                    {
                        System.out.println("Invaild must be higher");
                        num=getInt(Prompt,max);
                    }
                    return num;
    }
    
//**************************************************************************
    
    public static double getDouble()
{
{
    Scanner input = new Scanner(System.in);
        
    double num=0;
    
    while(!input.hasNextDouble())
        {
            System.out.println("invaild  re-enter: ");
            input.nextLine();
        }
    num = input.nextDouble();
    return num;
}
}
    
    public static double getDouble(String prompt)
    {
        System.out.print(prompt);
        return getInt();
    }
    
    public static double getDouble(String prompt,double max)
    {
    double num=0;
        System.out.print(prompt);
        num = getDouble();
            while(num>=max)
            {
                System.out.println(prompt);
            num = getDouble();
            }
        return num;
    }
    
    public static double getDouble(String prompt, double max, double min)
    {
    double num = 0;
            num=getDouble(prompt,max);
                    while(num<min)
                    {
                        System.out.println("Invaild must be higher");
                        num=getDouble(prompt,max);
                    }
                    return num;
    }
    
//******************************************************************************
    
    public static boolean checkAlpha(String word)
    {
        boolean isAlpha = true;
        String letter = "";
        final String ALPHA = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int index=0;
    for (int loc=0;loc<word.length();loc+=2)
    {
    letter = word.substring(loc, loc+1);
    index = ALPHA.indexOf(letter);
    if (index<0) isAlpha=false;
    }
        return isAlpha;
    }
    
    public static String getAlpha(String prompt)
    {
    Scanner input = new Scanner(System.in);
    
    String word="";
    boolean isAlpha=false;
    
        System.out.print(prompt);
        word = input.nextLine();
        isAlpha=checkAlpha(word);
        
        while(isAlpha=false)
        {
        System.out.print("re-enter "+prompt);
        word=input.nextLine();
        }
        return word;
    }
        //*****************************************************************
    
        public static int RandomNum(int max, int min)
        {
            int num=0;
            Random rand = new Random();
            num=rand.nextInt(max-min+1)+min;
            
            return num;
        }
        
        //******************************************************************
        public static void RandomFill (int[] array, int max, int min)
        {
            Random rand = new Random();
            for(int i=0;i<array.length;i++)
        {
            array[i]=rand.nextInt(max-min+1)+min;
        }
        }
    }